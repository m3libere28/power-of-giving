#!/usr/bin/env python3
"""Build the portable offline page and ZIP, excluding private runtime data/Git metadata."""
from pathlib import Path
import zipfile,re,shutil
root=Path(__file__).resolve().parent.parent
dist=root/'dist'
html=(dist/'index.html').read_text()
html=html.replace('<link rel="stylesheet" href="styles.css">','<style>'+(dist/'styles.css').read_text()+'</style>')
for name in ['calendar.js','backup.js','i18n.js','app.js']:
    code=(dist/name).read_text().replace('</', '<\\/')
    if name=='app.js':code=code.replace("(id==='explorer'?'Michelangelo':'')","''")
    html=html.replace('<script src="'+name+'"></script>','<script>'+code+'</script>')
html=html.replace('<a class="button" href="The-Power-of-Giving-Offline-Kit.zip" download>Download offline ZIP</a>','<p class="offline-notice"><strong>You are using the offline kit.</strong> Keep this folder and download a JSON backup to preserve your work.</p>')
html=html.replace('The ZIP is a blank family kit. Save a backup below to take your entered data with you.','To move your work to another computer, copy this folder and your downloaded JSON backup, then restore the backup there.')
assert not re.search(r'<script[^>]+src=',html)
assert '<link rel="stylesheet"' not in html
html=html.replace('href="giving-1.pdf"','href="The-Power-of-Giving-1.pdf"').replace('href="giving-2.pdf"','href="The-Power-of-Giving-2.pdf"')
(dist/'START-HERE.html').write_text(html)
shutil.copyfile(root/'AUDIT.md',dist/'AUDIT.md')
shutil.copyfile(root/'TESTING.md',dist/'TESTING.md')
leeme='''EL PODER DE DAR — PAQUETE SIN CONEXIÓN\n\n1. Descomprime todo el ZIP en una carpeta.\n2. Abre START-HERE.html en un navegador de ordenador.\n3. Elige Español o English en la bienvenida.\n4. Escribe tu nombre, tu plan y tus fechas.\n5. Descarga una copia de seguridad .json al terminar.\n6. Para cambiar de ordenador, copia la carpeta y la copia .json, y restaura esa copia desde la página.\n\nLos folletos originales están en The-Power-of-Giving-1.pdf y The-Power-of-Giving-2.pdf. Puedes abrirlos, guardarlos o imprimirlos.\n\nNo hace falta internet. El programa no envía los datos a nadie. La copia .json conserva notas, fechas, lista de presentación, camino, idioma y ajustes. Un informe .html/.txt es para leer, y un archivo .ics sirve para importar fechas en tu calendario.\n\nEl navegador puede perder datos si borras su almacenamiento, usas navegación privada o mueves la carpeta. Guarda siempre una copia .json.\n\nCurso: noviembre de 2026–abril de 2027. Jornada escolar: viernes 16 de abril de 2027; hora exacta pendiente de confirmación. Las demás fechas que elijas son familiares, no plazos adicionales del colegio.\n'''
archive=dist/'The-Power-of-Giving-Offline-Kit.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=8) as z:
    base='The-Power-of-Giving/'
    for name in ['START-HERE.html','giving-1.pdf','giving-2.pdf','AUDIT.md','TESTING.md']:
        z.write(dist/name,base+({'giving-1.pdf':'The-Power-of-Giving-1.pdf','giving-2.pdf':'The-Power-of-Giving-2.pdf'}.get(name,name)))
    z.write(root/'README.md',base+'README.md')
    z.writestr(base+'LEEME-ESPANOL.txt',leeme)
    for rel in ['README.md','AUDIT.md','TESTING.md','scripts/package.py','tests/calendar.test.cjs','.github/workflows/pages.yml']:
        z.write(root/rel,base+'source/'+rel)
    for name in ['index.html','styles.css','app.js','i18n.js','calendar.js','backup.js','giving-1.pdf','giving-2.pdf']:
        z.write(dist/name,base+'source/dist/'+name)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
print(str(archive));print('ZIP bytes:',archive.stat().st_size)
