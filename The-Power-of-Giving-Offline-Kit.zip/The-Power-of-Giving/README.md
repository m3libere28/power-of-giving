# The Power of Giving

A bilingual, animated, one-page family volunteering planner for the 2026–2027 school year. Built from the two supplied school flyers.

## Open the offline kit

1. Extract `The-Power-of-Giving-Offline-Kit.zip` completely.
2. Open `START-HERE.html` in a current desktop browser.
3. Choose English or Español on the welcome screen.
4. Enter your family's name and plan. Tap dates to save activities.
5. Download a JSON backup after working. Restore it to move your data to another browser or computer.

The offline page embeds all scripts, translations and styles. No installation, server, account, CDN, fonts or internet connection is required. The two original PDF flyers are included as `The-Power-of-Giving-1.pdf` and `The-Power-of-Giving-2.pdf` in the same folder. Open, save or print either PDF whenever you need it. Keep that folder together.

Browser local storage is convenient but not a backup. Clearing browser data, private browsing and moving a local file can change or remove its storage. If browser saving is unavailable, the page still allows downloads. JSON files restore project data; HTML/TXT reports are for reading; ICS files are for calendar applications. No data is sent automatically.

## Source and hosting

- `dist/index.html`: one-page hosted website.
- `dist/styles.css`: responsive layout and animations.
- `dist/app.js`: interactions, planner, local saving, reports and date editor.
- `dist/i18n.js`: English/Spanish UI translation.
- `dist/calendar.js`: date validation and standards-based ICS export.
- `dist/backup.js`: strict backup validation.
- `scripts/package.py`: creates self-contained offline HTML and ZIP.
- `AUDIT.md`: coverage of both flyers and the full schedule.
- `TESTING.md`: test evidence and limitations.

Run `node --test tests/calendar.test.cjs` for calendar/backup checks and `python scripts/package.py` to rebuild the offline kit. No npm dependencies or build tools are required.

GitHub Pages deployment workflow is supplied in `.github/workflows/pages.yml`. After the repository is created, choose **Settings → Pages → Source: GitHub Actions**. The workflow publishes `dist/`. Use the repository's chosen visibility and Pages access intentionally: standard GitHub Pages websites are publicly reachable. The currently hosted ChatGPT Site remains private unless its owner changes access.

## School dates

November 2026 through April 2027. Open house: Friday 16 April 2027, during the school day; exact time to be supplied by school. Other stages are time windows, not invented deadlines. Calendar downloads are date-only.

## Español

Extrae todo el ZIP y abre `START-HERE.html`. Elige **Español**. No hace falta instalar nada ni conectarse a internet. Guarda una copia de seguridad **.json** al terminar para conservar notas, fechas y listas o trasladarlas a otro ordenador. Los informes **.html/.txt** son para leer; los archivos **.ics**, para importar en tu calendario. Restaurar una copia sustituye los datos de este proyecto en ese navegador.
